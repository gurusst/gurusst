package com.fino.esb;

/**
 * An interface for implementing Hello services.
 */
public interface Hello {

    String hello();
	
}
